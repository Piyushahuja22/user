package com.instainsurance.insuranceappl.services;

import java.util.List;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.Policy;

public interface PolicyServices {
	Boolean insertPolicy(Policy policy) throws InsuranceException;
	Boolean updatePolicy(Policy policy) throws InsuranceException;
	Boolean deletePolicy(Policy policy) throws InsuranceException;
	Policy findByPolicyId(String id) throws InsuranceException;
	List<Policy> getPolicies();
	List<Policy> getPolicies(String category);
}
