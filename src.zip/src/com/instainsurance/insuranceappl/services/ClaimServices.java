package com.instainsurance.insuranceappl.services;

import java.util.List;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.Claim;

public interface ClaimServices {
	Boolean insertClaim(Claim claim) throws InsuranceException;
	Boolean updateClaim(Claim claim) throws InsuranceException;
	Boolean deleteClaim(Claim claim) throws InsuranceException;
	Claim findByClaimId(String id) throws InsuranceException;
	List<Claim> getClaims() throws InsuranceException;
}
