package com.instainsurance.insuranceappl.services;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.VehiclesData;

public interface VehiclesDataServices {
	Boolean insertVehicle(VehiclesData vehiclesData) throws InsuranceException;
	Boolean updateVehicle(VehiclesData vehiclesData) throws InsuranceException;
	Boolean deleteVehicle(VehiclesData vehiclesData) throws InsuranceException;
	VehiclesData findByVehicleDataId(String id) throws InsuranceException;
	
}
