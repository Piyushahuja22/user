package com.instainsurance.insuranceappl.services;

import java.util.List;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.Customer;
import com.instainsurance.insuranceappl.models.Vehicle;

public interface VehicleServices {
	Boolean insertVehicle(Vehicle vehicle)throws InsuranceException;
	Boolean updateVehicle(Vehicle vehicle)throws InsuranceException;
	Boolean deleteVehicle(Vehicle vehicle)throws InsuranceException;
	Vehicle findByVehicleId(String id)throws InsuranceException;
	List<Vehicle> getVehicles();
	
	
	public Vehicle findByVehicleCustomer(Customer id)throws InsuranceException;
}
