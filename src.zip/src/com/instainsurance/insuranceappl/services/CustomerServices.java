package com.instainsurance.insuranceappl.services;

import java.util.List;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.Customer;

public interface CustomerServices {
	Boolean insertCustomer(Customer customer) throws InsuranceException;
	Boolean updateCustomer(Customer customer) throws InsuranceException;
	Boolean deleteCustomer(Customer customer) throws InsuranceException;
	Customer findByCustomerId(String id) throws InsuranceException;
	List<Customer> getCustomer() throws InsuranceException;
//	public Customer checkLogin(String userName, String userPassword);
}
