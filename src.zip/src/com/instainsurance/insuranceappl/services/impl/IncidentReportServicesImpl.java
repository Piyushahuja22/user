package com.instainsurance.insuranceappl.services.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.instainsurance.insuranceappl.daos.IncidentDao;
import com.instainsurance.insuranceappl.daos.IncidentReportDao;
import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.IncidentReport;
import com.instainsurance.insuranceappl.services.IncidentReportServices;

@Service
public class IncidentReportServicesImpl implements IncidentReportServices{

	@Resource
	private IncidentReportDao dao;

	@Override
	public Boolean insertIncidentReport(IncidentReport incidentReport) throws InsuranceException {
		return dao.insertIncidentReport(incidentReport);
	}

	@Override
	public Boolean updateIncidentReport(IncidentReport incidentReport) throws InsuranceException {
		return dao.updateIncidentReport(incidentReport);
	}

	@Override
	public Boolean deleteIncidentReport(IncidentReport incidentReport) throws InsuranceException {
		return dao.deleteIncidentReport(incidentReport);	
	}

	@Override
	public IncidentReport findByIncidentReportId(String id) throws InsuranceException {
		return dao.findByIncidentReportId(id);
	}

	@Override
	public List<IncidentReport> getIncidentReports() {
		return dao.getIncidentReports();
	}
	
	

}
