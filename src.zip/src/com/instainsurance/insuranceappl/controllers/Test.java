package com.instainsurance.insuranceappl.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.instainsurance.insuranceappl.daos.impl.VehiclesDataDaoImpl;
import com.instainsurance.insuranceappl.models.Policy;
import com.instainsurance.insuranceappl.models.TempQuote;
import com.instainsurance.insuranceappl.models.VehiclesData;
import com.instainsurance.insuranceappl.services.PolicyServices;
import com.instainsurance.insuranceappl.services.TempQuoteServices;
import com.instainsurance.insuranceappl.services.VehiclesDataServices;
import com.instainsurance.insuranceappl.services.impl.PolicyServicesImpl;
import com.instainsurance.insuranceappl.services.impl.VehiclesDataServicesImpl;

@Controller
public class Test {
	
/*	@Autowired
	private TempQuoteServices tqservices;

	@RequestMapping("test")
	public ModelAndView Test1() {
		
		ModelAndView mAndV = new ModelAndView("Test");
		mAndV.addObject("pageTitle", "List of all tempQuotes");
		
		return mAndV;
	}	
	
	@RequestMapping("listAllTempQuote")
	public ModelAndView Test2() {
		List<TempQuote> tqList = tqservices.getTempQuotes();
		
		ModelAndView mAndV = new ModelAndView("Test");
		mAndV.addObject("tqList", tqList);
		mAndV.addObject("pageTitle", "List of all tempQuotes");
		
		return mAndV;
	}

   public void getQuote( String newOrOldCar, String makerName , String carYouDrive , String fuelType ) {
	
	   String vehiclesMakerName = makerName + " " + carYouDrive + " " + fuelType;
	   
	   System.out.println(vehiclesMakerName);
	   ApplicationContext context = new ClassPathXmlApplicationContext("springCore.xml");
	   
	   VehiclesDataServices vehiclesDataServices = (VehiclesDataServices) context.getBean("VehiclesDataServices");
	   PolicyServices policyServices = (PolicyServices) context.getBean("PolicyServices");
	   
	  
	   VehiclesData vehiclesData =  (VehiclesData) vehiclesDataServices.findByVehicleDataId(vehiclesMakerName);
	   
	   Double price = (Double) vehiclesData.getVehiclesValue();
	   
	   System.out.println(vehiclesData.getVehiclesValue());
	   
	   // pass to getPrice fn 
	   Test test = new Test();
	   
	   if(newOrOldCar.equals("old")) {
		   price = price - (0.2 * price);
	   }
	   
	   
	   String category = test.getCategory(price);
	   
	   System.out.println("Test.java : " + category);
	   
	   
	  
	   List<Policy> policies = policyServices.getPolicies(category);
	   

	   
	   for(Policy policy: policies) {
		   System.out.println(policy);
	   }
	   
	   
	   
   }
   
   public String getCategory(Double price) {
	   String category ; 
	   
	   if(price > 0 && price < 500000) {
		  category= "Basic" ;
	   }

	   if(price > 500000 && price < 1000000) {
			  category= "Medium" ;
		   }
	   if(price > 1000000 && price < 2000000) {
			  category= "High" ;
		   }
	   if(price > 2000000 && price < 4000000) {
			  category= "Luxury" ;
		   } 
	   else {
		   category="Deluxe";
	   }
	   
	   return category;
	   
      } 
	 
   */
}

