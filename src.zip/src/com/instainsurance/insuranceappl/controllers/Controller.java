package com.instainsurance.insuranceappl.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.Policy;
import com.instainsurance.insuranceappl.models.TempQuote;
import com.instainsurance.insuranceappl.models.VehiclesData;
import com.instainsurance.insuranceappl.services.PolicyServices;
import com.instainsurance.insuranceappl.services.TempQuoteServices;
import com.instainsurance.insuranceappl.services.VehiclesDataServices;

@RestController
public class Controller {

	// step 1 : create instance of Service and
	// annotate it with @Autowired
	@Autowired
	TempQuoteServices tempQuoteService;

	
	
	@RequestMapping(value ="/getTempQuotes", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<TempQuote> getTempQuotes(Model model) {
		return tempQuoteService.getTempQuotes();
	}
	

	@RequestMapping(value = "/insertTempQuotes/{oldOrNew}/{type}/{registration}/{name}/{variant}/{place}/{fuel}/{firstName}/{lastName}/{emailId}/{contactNumber}/{vehicleMaker}", headers = "Accept=application/json", method = RequestMethod.POST)
	public List<Policy> insertTempQuote(
			@PathVariable String oldOrNew,
			@PathVariable String type,
			@PathVariable String registration,
			@PathVariable String name,
			@PathVariable String variant,
			@PathVariable String place,
			@PathVariable String fuel,
			@PathVariable String firstName, 
			@PathVariable String lastName,
			@PathVariable String emailId,
			@PathVariable String contactNumber,
			@PathVariable String vehicleMaker
			){
		
		
		System.out.println(oldOrNew+" "+type+" "+registration+" "+
				name+" "+variant+" "+place+" "+fuel+" "+firstName+" "+lastName+" "
				+emailId+" "+contactNumber + " " + vehicleMaker);
				
			TempQuote tempQuote = new TempQuote();
			int counter = tempQuoteService.getTempQuotes().size();
			System.out.println(counter);
			tempQuote.setIndex(++counter);
			tempQuote.setVehicleOldOrNew(oldOrNew);
			tempQuote.setVehicleType(type);
			tempQuote.setVehicleRegNo(registration);
			tempQuote.setModel(name);
			tempQuote.setVehicleModelNo(variant);
			tempQuote.setVehicleRegPlace(place);
			tempQuote.setVehicleFuel(fuel);
			tempQuote.setCustomerFirstName(firstName);
			tempQuote.setCustomerLastName(lastName);
			tempQuote.setCustomerEmail(emailId);
			tempQuote.setCustomerMobNo(contactNumber);
			
			try {
				Boolean flag = tempQuoteService.insertTempQuote(tempQuote);
			} catch (InsuranceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println();
		return getQuote(oldOrNew,type , vehicleMaker, name, fuel);
//			return getQuote("old","four","Honda","Brio","Petrol");
}
	
	
	
	
	public List<Policy> getQuote( String newOrOldCar, String twoOrFourWheeler, String makerName , String carYouDrive , String fuelType ) {
		
		   String vehiclesMakerName = makerName.trim() + " " + carYouDrive.trim() + " " + fuelType.trim();
		   
		   ApplicationContext context = new ClassPathXmlApplicationContext("springCore.xml");
		   
		   VehiclesDataServices vehiclesDataServices = (VehiclesDataServices) context.getBean("VehiclesDataServices");
		   PolicyServices policyServices = (PolicyServices) context.getBean("PolicyServices");

		   VehiclesData vehiclesData = null;
		try {
			vehiclesData = (VehiclesData) vehiclesDataServices.findByVehicleDataId(vehiclesMakerName);
		} catch (InsuranceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   Double price = (Double) vehiclesData.getVehiclesValue();

		   Controller controller = new Controller();
		   
		   System.out.println(price);
		   
		   if(newOrOldCar.equals("old")) {
			   price = price - (0.2 * price);
		   }
		   	   
		   System.out.println(price);
		   
		   String category = "";
		   
		   if(twoOrFourWheeler.equals("two")) 
			   category = controller.getCategoryForTwoWheeler(price);
		   else 
			   category = controller.getCategoryForFourWheeler(price);
	  
		   List<Policy> policies = policyServices.getPolicies(category);
		   for(Policy policy: policies) {
			   System.out.println(policy);
		   }
		   	   
		   return policies;
		   
	   }
	   
	   public String getCategoryForFourWheeler(Double price) {
		   String category = null ; 
		   
		   if(price > 0 && price <= 500000) {
			  category= "Basic" ;
		   } else
		   if(price > 500000 && price <= 1000000) {
				  category= "Medium" ;
		   } else
		   if(price > 1000000 && price <= 2000000) {
				  category= "High" ;
		   } else
		   if(price > 2000000 && price <= 4000000) {
				  category= "Luxury" ;
		   } else
		   if(price > 4000000) {
			   category = "Deluxe" ;
		   }
		   
		   return category;   
	    } 
		 
	   public String getCategoryForTwoWheeler(Double price) {
		   String category ; 
		   
		   if(price > 0 && price < 5000) {
			  category= "Basic" ;
		   } else
		   if(price > 5000 && price < 30000) {
				  category= "Medium" ;
		   } else
		   if(price > 30000 && price < 80000) {
				  category= "High" ;
		   } else {
			   category="Deluxe";
		   }   
		   return category;   
	    } 

}
