package com.instainsurance.insuranceappl.daos;

import java.util.List;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.User;

public interface UserDao {

	Boolean insertUser(User user) throws InsuranceException;
	Boolean updateUser(User user) throws InsuranceException;
	Boolean deleteUser(User user) throws InsuranceException;
	User findByUserId(String id) throws InsuranceException;
	List<User> getUsers();
	
}
