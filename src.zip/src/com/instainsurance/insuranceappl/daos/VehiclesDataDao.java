package com.instainsurance.insuranceappl.daos;


import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.VehiclesData;

public interface VehiclesDataDao {

	Boolean insertVehicleData(VehiclesData vehicledata) throws InsuranceException;
	Boolean updateVehicleData(VehiclesData vehicledata) throws InsuranceException;
	Boolean deleteVehicleData(VehiclesData vehicledata) throws InsuranceException;
	VehiclesData findByVehicleDataId(String id) throws InsuranceException;	
}
