package com.instainsurance.insuranceappl.daos;

import java.util.List;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.Quote;

public interface QuoteDao {

	Boolean insertQuote(Quote quote) throws InsuranceException;
	Boolean updateQuote(Quote quote) throws InsuranceException;
	Boolean deleteQuote(Quote quote) throws InsuranceException;
	Quote findByQuoteId(String id) throws InsuranceException;
	List<Quote> getQuotes();
}
