/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sendsms;

/**
 *
 * @author Ahuja
 */
public class SmsCredentials {
    //private String username = 
            
    String api = "e46f091c-210f-11e8-a895-0200cd936042";
    
}
